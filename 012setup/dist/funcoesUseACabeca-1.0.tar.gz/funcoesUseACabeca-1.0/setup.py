from setuptools import setup


setup(
    name='funcoesUseACabeca',
    version='1.0',
    description='Primeiro modulo externo feito para encontrar letras',
    author='Wagner',
    author_email='spamdowagner@gmail.com',
    url='https://github.com/wagnersouzadepaula',
    py_modules=['funcoesUseACabeca'],
)
